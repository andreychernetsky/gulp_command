'use strict';

const countTypesInArray = null;

module.exports = { countTypesInArray };
