'use strict';

const fn = () => {
  console.log({ a });
  var a = 5;
};

module.exports = { fn };
