'use strict';

const inc = x => ++x;

module.exports = { inc };
